Grupo: Richard Delgado Garzón, Santiago Gomez y Andres Santacruz
